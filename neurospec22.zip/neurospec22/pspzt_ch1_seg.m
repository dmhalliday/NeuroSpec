function pspzt_ch1_seg(coh,cl,seg_no,freq,ch_max,label)
% pspzt_ch1_seg(coh,cl,seg_no,freq,ch_max,label)
%
% function to plot time coherence at fixed segment in z-tracker estimate in current figure/subplot window
%  
% Copyright (C) 2018, David M. Halliday.
% This file is part of NeuroSpec.
%
%    NeuroSpec is free software; you can redistribute it and/or modify
%    it under the terms of the GNU General Public License as published by
%    the Free Software Foundation; either version 2 of the License, or
%    (at your option) any later version.
%
%    NeuroSpec is distributed in the hope that it will be useful,
%    but WITHOUT ANY WARRANTY; without even the implied warranty of
%    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%    GNU General Public License for more details.
%
%    You should have received a copy of the GNU General Public License
%    along with NeuroSpec; if not, write to the Free Software
%    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
%
%    NeuroSpec is available at:  http://www.neurospec.org/
%     Contact:  contact@neurospec.org
%
% coh,cl    Output from z-tracker analysis function, sp2a2_zt
% seg_no    Number of segment ot plot, range 1 - L, where L is no of segments
% freq      Frequency limit for plotting (Hz).
% ch_max    Maximum value of y axis (Optional).
% label     Optional title instead of cl.what.
%
% pspzt_ch1_seg(coh,cl,seg_no,freq,ch_max,label)

if (nargin<4)
  error('Not enough input arguments')
end  
if (cl(1).type~=30)
  error('Not type 30 (z-tracker) analysis')
end

% Check indices
[n_freq,n_seg]=size(coh);
if (seg_no<1)
  error('Error in seg_no: Minimum index is 1')
end 
if max(seg_no)>n_seg
  error(['Error in seg_no: Requested segment too large. No of segments: ',num2str(n_seg)]);
end

% Time index for z-tracker segments, using mid-point of each segment
%  start at T/2 for 1st segment
T=cl.seg_size;
n_seg=cl.seg_tot;
t_seg=(T/2+T*(0:n_seg-1)')/cl.samp_rate;

% Frequencies
plot_ind=find(cl.ost_freqs<=freq);
if (length(plot_ind)>n_freq)
  error('Requested frequency range too large.');
end
if (length(plot_ind)<1)
  error('Requested frequency range too narrow.');
end

% Extract coherence values
r2_dat=coh(:,seg_no);

% Extract Pk values
Pk=cl.ost_P(seg_no);

% Matrices with upper and lower point-wise confidence limits.
r2_dat_clu=atanh(sqrt(r2_dat));  % working in z-domain
r2_dat_cll=r2_dat_clu;

r2_dat_clu=r2_dat_clu+1.96*sqrt(Pk);  % Upper 95% CL
r2_dat_cll=r2_dat_cll-1.96*sqrt(Pk);  % Lower 95% CL

% Cap lower CL at zero
r2_dat_cll(find(r2_dat_cll<0))=0;
r2_dat_clu=tanh(r2_dat_clu).^2;  % Convert back to coherence domain
r2_dat_cll=tanh(r2_dat_cll).^2;

% Ploting
plot(cl.ost_freqs(plot_ind),r2_dat(plot_ind),'k-','LineWidth',2)
hold on
% Add in Confidence limits
plot(cl.ost_freqs(plot_ind),r2_dat_clu(plot_ind),'k-')
plot(cl.ost_freqs(plot_ind),r2_dat_cll(plot_ind),'k-')
hold off

if (nargin<5)
  axis([0,freq,0,Inf]);
else
  axis([0,freq,0,ch_max]);
end  
xlabel('Frequency (Hz)')

if (nargin>5)
  title(label);
else
 title(['ztrack coh, Seg: ',num2str(seg_no),', time: ',num2str(t_seg(seg_no)),'. ',cl.what]);
end  
